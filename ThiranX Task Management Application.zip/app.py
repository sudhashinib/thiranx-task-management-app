from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from pathlib import Path
from functools import wraps

app = Flask(__name__)
app.secret_key = "replace-this-with-a-long-random-secret-key"
DB_PATH = Path(__file__).with_name("tasks.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT DEFAULT '',
                priority TEXT NOT NULL DEFAULT 'Medium',
                status TEXT NOT NULL DEFAULT 'Pending',
                due_date TEXT DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """)

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 6:
            flash("Username must be at least 3 characters and password at least 6 characters.")
            return render_template("register.html")
        try:
            with get_db() as conn:
                conn.execute(
                    "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                    (username, generate_password_hash(password))
                )
            flash("Account created. Please log in.")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That username is already taken.")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with get_db() as conn:
            user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.")
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    status_filter = request.args.get("status", "All")
    with get_db() as conn:
        if status_filter in ("Pending", "In Progress", "Completed"):
            tasks = conn.execute(
                "SELECT * FROM tasks WHERE user_id = ? AND status = ? ORDER BY created_at DESC",
                (session["user_id"], status_filter)
            ).fetchall()
        else:
            tasks = conn.execute(
                "SELECT * FROM tasks WHERE user_id = ? ORDER BY created_at DESC",
                (session["user_id"],)
            ).fetchall()
        stats = conn.execute("""
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending,
                   SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) AS progress,
                   SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) AS completed
            FROM tasks WHERE user_id = ?
        """, (session["user_id"],)).fetchone()
    return render_template("dashboard.html", tasks=tasks, stats=stats, status_filter=status_filter)

@app.route("/tasks/add", methods=["POST"])
@login_required
def add_task():
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    priority = request.form.get("priority", "Medium")
    due_date = request.form.get("due_date", "")
    if not title:
        flash("Task title is required.")
    else:
        if priority not in ("Low", "Medium", "High"):
            priority = "Medium"
        with get_db() as conn:
            conn.execute("""
                INSERT INTO tasks (user_id, title, description, priority, due_date)
                VALUES (?, ?, ?, ?, ?)
            """, (session["user_id"], title, description, priority, due_date))
        flash("Task added successfully.")
    return redirect(url_for("dashboard"))

@app.route("/tasks/update/<int:task_id>", methods=["POST"])
@login_required
def update_task(task_id):
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    priority = request.form.get("priority", "Medium")
    status = request.form.get("status", "Pending")
    due_date = request.form.get("due_date", "")
    if not title:
        flash("Task title cannot be empty.")
        return redirect(url_for("dashboard"))
    if priority not in ("Low", "Medium", "High"):
        priority = "Medium"
    if status not in ("Pending", "In Progress", "Completed"):
        status = "Pending"
    with get_db() as conn:
        conn.execute("""
            UPDATE tasks
            SET title = ?, description = ?, priority = ?, status = ?, due_date = ?
            WHERE id = ? AND user_id = ?
        """, (title, description, priority, status, due_date, task_id, session["user_id"]))
    flash("Task updated.")
    return redirect(url_for("dashboard"))

@app.route("/tasks/delete/<int:task_id>", methods=["POST"])
@login_required
def delete_task(task_id):
    with get_db() as conn:
        conn.execute("DELETE FROM tasks WHERE id = ? AND user_id = ?", (task_id, session["user_id"]))
    flash("Task deleted.")
    return redirect(url_for("dashboard"))

@app.route("/health")
def health():
    return {"status": "ok", "database": "connected"}

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
