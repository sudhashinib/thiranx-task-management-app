const dateBox = document.getElementById("todayDate");
if (dateBox) {
  dateBox.textContent = new Intl.DateTimeFormat("en-IN", {
    weekday: "short", day: "numeric", month: "short", year: "numeric"
  }).format(new Date());
}
