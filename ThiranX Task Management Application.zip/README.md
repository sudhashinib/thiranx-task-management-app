# TaskFlow – ThiranX Task Management Application

A responsive full-stack task manager built with HTML, CSS, JavaScript, Python Flask and SQLite.

## Features
- User registration and login.
- Passwords stored as secure hashes (not plain text).
- User-specific task lists.
- Create, read, update and delete tasks (CRUD).
- Task priority: Low, Medium, High.
- Task status: Pending, In Progress, Completed.
- Optional due dates and task descriptions.
- Filter tasks by status.
- Dashboard counts for total, pending, in-progress and completed tasks.
- Responsive layout for desktop and mobile.
- `/health` endpoint for a basic application health check.

## Run locally

1. Install Python 3.10 or later.
2. Extract this ZIP file.
3. Open a terminal inside the extracted `thiranx_task_management_app` folder.
4. (Recommended) Create and activate a virtual environment:

   Windows:
   `python -m venv venv`
   `venv\\Scripts\\activate`

   macOS/Linux:
   `python3 -m venv venv`
   `source venv/bin/activate`

5. Install packages:
   `pip install -r requirements.txt`

6. Run:
   `python app.py`

7. Open `http://127.0.0.1:5000` in your browser.
8. Select **Create account**, register, log in and start adding tasks.

The `tasks.db` SQLite database is created automatically on first run.

## Important before deployment
- Replace `app.secret_key` in `app.py` with a long random secret stored as an environment variable.
- Turn off Flask debug mode in production.
- Use HTTPS in production.
- For deployment, configure a persistent database/storage so user accounts and tasks are not lost when the host restarts or redeploys.
- This starter project uses standard Flask form routes and SQLite. It does not include WebSockets; task updates appear after refreshing/submitting the page.
